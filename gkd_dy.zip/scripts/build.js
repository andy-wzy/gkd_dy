import fs from "fs";
import path from "path";
import JSON5 from "json5";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const upstreamDir = path.resolve(__dirname, "..", "upstream");
const distDir = path.resolve(__dirname, "..", "dist");
const sourcesPath = path.resolve(__dirname, "..", "config", "sources.json");

console.log("=== 开始构建 ===");
console.log(`upstream目录: ${upstreamDir}`);
console.log(`dist目录: ${distDir}`);
console.log("");

if (!fs.existsSync(upstreamDir)) {
  console.error("❌ upstream 目录不存在，请先运行 npm run sync");
  process.exit(1);
}

if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
  console.log(`✓ 创建dist目录: ${distDir}`);
}

const sourceFiles = fs.readdirSync(upstreamDir);
console.log(`发现 ${sourceFiles.length} 个文件`);

const mergedResult = {
  $schema: "https://gkd.li/schema/gkd-subscription.json",
  id: "gkd-dy-merged",
  name: "GKD-DY 合并订阅",
  version: Date.now(),
  author: "gkd-dy",
  categories: [],
  globalGroups: [],
  apps: []
};

let totalRules = 0;

for (const file of sourceFiles) {
  if (!file.endsWith(".json5")) continue;

  const filePath = path.join(upstreamDir, file);
  console.log(`\n处理: ${file}`);

  try {
    const content = fs.readFileSync(filePath, "utf8");
    console.log(`  文件大小: ${content.length} 字节`);
    
    const data = JSON5.parse(content);
    console.log(`  解析成功`);

    if (data.categories && Array.isArray(data.categories)) {
      data.categories.forEach(cat => {
        if (!mergedResult.categories.some(c => c.key === cat.key)) {
          mergedResult.categories.push(cat);
        }
      });
      console.log(`  ✓ 分类: ${data.categories.length} 个`);
    }

    if (data.globalGroups && Array.isArray(data.globalGroups)) {
      data.globalGroups.forEach(group => {
        mergedResult.globalGroups.push(group);
        if (group.rules) {
          totalRules += group.rules.length;
        }
      });
      console.log(`  ✓ 全局规则组: ${data.globalGroups.length} 个`);
    }

    if (data.apps && Array.isArray(data.apps)) {
      data.apps.forEach(app => {
        const existingApp = mergedResult.apps.find(a => a.id === app.id);
        if (existingApp) {
          if (app.groups && Array.isArray(app.groups)) {
            existingApp.groups = existingApp.groups || [];
            existingApp.groups.push(...app.groups);
            app.groups.forEach(g => {
              if (g.rules) totalRules += g.rules.length;
            });
          }
        } else {
          mergedResult.apps.push({ ...app });
          if (app.groups && Array.isArray(app.groups)) {
            app.groups.forEach(g => {
              if (g.rules) totalRules += g.rules.length;
            });
          }
        }
      });
      console.log(`  ✓ 应用: ${data.apps.length} 个`);
    }

  } catch (error) {
    console.error(`  ✗ 错误: ${error.message}`);
  }
}

mergedResult.globalGroups.sort((a, b) => (b.order || 0) - (a.order || 0));
mergedResult.apps.sort((a, b) => (a.id || "").localeCompare(b.id || ""));

const outputPath = path.join(distDir, "gkd.json5");
fs.writeFileSync(outputPath, JSON5.stringify(mergedResult, null, 2));

console.log("\n=== 构建完成 ===");
console.log(`输出文件: ${outputPath}`);
console.log(`应用数: ${mergedResult.apps.length}`);
console.log(`全局规则组数: ${mergedResult.globalGroups.length}`);
console.log(`分类数: ${mergedResult.categories.length}`);
console.log(`总规则数: ${totalRules}`);
